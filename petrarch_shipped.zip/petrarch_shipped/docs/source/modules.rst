PETRARCH Package
========================

:mod:`petrarch` Module
----------------------
                
.. automodule:: petrarch
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`PETRglobals` Module
-------------------------

.. automodule:: PETRglobals
    :members:
    :undoc-members:
    :show-inheritance:
        
:mod:`PETRreader` Module
------------------------
        
.. automodule:: PETRreader
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`PETRwriter` Module
------------------------
                
.. automodule:: PETRwriter
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`utilities` Module
-----------------------
                
.. automodule:: utilities
    :members:
    :undoc-members:
    :show-inheritance:

:mod:`PETRtree` Module
-----------------------
                
.. automodule:: PETRtree
    :members:
    :undoc-members:
    :show-inheritance:
